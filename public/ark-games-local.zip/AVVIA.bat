@echo off
echo ==========================================
echo    ARK GAMES - Server Locale
echo ==========================================
echo.
echo Avvio server su http://localhost:8080
echo.
echo PAGINE:
echo   Admin:    http://localhost:8080/admin.html
echo   Regia:    http://localhost:8080/regia.html
echo   Stream:   http://localhost:8080/stream.html
echo   TV:       http://localhost:8080/tv.html
echo.
echo Premi CTRL+C per chiudere
echo ==========================================
python -m http.server 8080
