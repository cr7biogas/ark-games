===============================================
  ARK GAMES - Pacchetto Locale
===============================================

COME USARE:

1. Estrai questa cartella sul PC

2. Doppio click su "AVVIA.bat"

3. Apri nel browser:
   - Regia camere:  http://localhost:8080/regia.html
   - Stream (YT):   http://localhost:8080/stream.html
   - Admin/Timer:   http://localhost:8080/admin.html
   - TV Monitor:    http://localhost:8080/tv.html
   - Leaderboard:   http://localhost:8080/leaderboard.html

REQUISITI:
- Python installato (https://python.org)
- Durante installazione Python, spunta "Add to PATH"

ALTERNATIVA (se hai Node.js):
- Apri terminale in questa cartella
- Esegui: npx serve -p 8080
- Apri http://localhost:8080

===============================================
